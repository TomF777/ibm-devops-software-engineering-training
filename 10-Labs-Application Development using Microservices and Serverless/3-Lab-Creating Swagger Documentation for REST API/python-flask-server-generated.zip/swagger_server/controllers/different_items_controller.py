import connexion
import six

from swagger_server import util


def items_get():  # noqa: E501
    """Returns a list of items

    Returns items  # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
